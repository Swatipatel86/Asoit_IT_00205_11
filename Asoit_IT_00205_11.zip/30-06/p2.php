<?php
if(isset($_POST["submit"]))
{
    if(isset($_POST["no1"]) && isset($_POST["no2"])){
        $no1=$_POST["no1"];
        $no2=$_POST["no2"];
        $res=$no1+$no2;
    }
}
?>
<html>

<form action="#" method="post">
<input type="text" id="fname" name="no1"><br><br>
<input type="text" id="fname" name="no2"><br><br>
<input type="submit" value="submit" name="submit"><br><br>
<input type="text" name="result" value="<?php if(isset($res)) {echo $res;}?>">
</form>
</html>
